
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "unblock.oxylabs.io",
                port: parseInt(60000)
            },
            bypassList: ["localhost"]
        }
    };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "hung1221_4E5DC",
                    password: "Hung1221++++"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    